import kfp
# When not specified, host defaults to env var KF_PIPELINES_ENDPOINT.
client = kfp.Client()
print(client.list_experiments())