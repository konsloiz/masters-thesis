helm install jupyter jupyterhub/jupyterhub --version=v0.11.0 -f config.yaml -n kubeflow --timeout 180s

kubectl port-forward -n kubeflow svc/proxy-public 8888:80
