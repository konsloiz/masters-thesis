def serve(model: Any,
          name: str,
          version: str = "latest",
          wait: bool = True,
          predictor: str = None,
          preprocessing_fn: Callable = None,
          preprocessing_assets: Dict = None) -> KFServer:

    log.info("Starting serve procedure for model '%s'", model)
    if not version:
        log.info("No version provided, using 'latest'")

    # Validate and process transformer
    if preprocessing_fn:
        _prepare_transformer_assets(preprocessing_fn, preprocessing_assets)

    # Detect predictor type
    predictor_type = marshal.get_backend(model).predictor_type
    if predictor and predictor != predictor_type:
        raise RuntimeError("Trying to create an InferenceService with"
                           " predictor of type '%s' but the model is of type"
                           " '%s'" % (predictor, predictor_type))
    if not predictor_type:
        log.error("Kale does not yet support serving objects with '%s'"
                  " backend.\n\nPlease help us improve Kale by opening a new"
                  " issue at:\n"
                  "https://github.com/kubeflow-kale/kale/issues",
                  marshal.get_backend(model).display_name)
        utils.graceful_exit(-1)
    predictor = predictor_type  # in case `predictor` is None

    # Dump the model
    marshal.set_data_dir(PREDICTOR_MODEL_DIR)
    model_filepath = marshal.save(model, "model")

    model_filename = model_filepath.split('/')[-1]
    
    # Save the model to minio bucket
    minio_path = f"{podutils.get_namespace()}/{name}/{version}/{model_filename}"

    model_uri = f"{MINIO_BUCKET}/{podutils.get_namespace()}/{name}/{version}"

    model_name = f"{name}-{version}"

    if is_file(model_filepath):
        save_file_to_minio(minio_path, model_filepath, model_uri)
    else:
        save_dir_to_minio(minio_path, model_filepath, model_uri)
        model_parent_dir=minio_path.split('/')[3]
        model_uri= f"{model_uri}/{model_parent_dir}"

    return serve_from_uri(model_uri, predictor, model_name, wait, preprocessing_fn, preprocessing_assets)


def save_file_to_minio(minio_path, model_filepath, model_uri):
    minio_client = Minio('minio-service.kubeflow.svc.cluster.local:9000', access_key='*****', secret_key='****', secure=False)
    try:
        minio_client.fput_object(MINIO_BUCKET, minio_path, model_filepath)
        log.info("Model file saved successfully at {}".format(model_uri))
        # delete the locally saved model file
        os.remove(model_filepath)


    except InvalidResponseError as err:
        raise InvalidResponseError("Invalid response error {}".format(err))


def save_dir_to_minio(minio_path, model_filepath, model_uri):
    for model_file in glob.glob(model_filepath + '/**'):
        if os.path.isdir(model_file):
            save_dir_to_minio(
                minio_path + "/" + os.path.basename(model_file), model_file, model_uri)
        else:
            remote_path = os.path.join(
                minio_path, model_file[1 + len(model_filepath):])
            save_file_to_minio(remote_path, model_file, model_uri)