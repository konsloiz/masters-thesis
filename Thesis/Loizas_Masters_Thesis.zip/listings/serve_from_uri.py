def serve_from_uri(model_uri: str,
                   predictor: str,
                   name: str = None,
                   wait: bool = True,
                   preprocessing_fn: Callable = None,
                   preprocessing_assets: Dict = None) -> KFServer:
  
    log.info("Starting serve procedure for model '%s'", model_uri)

    if predictor not in PREDICTORS:
        raise ValueError("Invalid predictor: %s. Choose one of %s"
                         % (predictor, PREDICTORS))

    if not name:
        name = "%s-%s" % (podutils.get_pod_name(), utils.random_string(5))

    # Validate and process transformer
    if preprocessing_fn:
        _prepare_transformer_assets(preprocessing_fn, preprocessing_assets)

    log.info("Creating inference service")

    kfserver = create_inference_service_from_uri(
        name=name,
        predictor=predictor,
        model_path=model_uri,
        transformer=preprocessing_fn is not None)

    if wait:
        monitor_inference_service(kfserver.name)
    return kfserver
    