#include <iostream>                                     

// Hauptfunktion
int main(){                                             
    std::cout << "hello world" << std::endl;

    return EXIT_SUCCESS;                                           
}