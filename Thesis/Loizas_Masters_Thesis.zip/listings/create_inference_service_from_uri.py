def create_inference_service_from_uri(name: str,
                                      predictor: str,
                                      model_path: str,
                                      image: str = None,
                                      port: int = None,
                                      transformer: bool = False,
                                      submit: bool = True) -> KFServer:

    if predictor not in PREDICTORS:
        raise ValueError("Invalid predictor: %s. Choose one of %s"
                         % (predictor, PREDICTORS))

    if predictor == "custom":
        if not image:
            raise ValueError("You must specify an image when using a custom"
                             " predictor.")
        if not port:
            raise ValueError("You must specify a port when using a custom"
                             " predictor.")
        predictor_spec = CUSTOM_PREDICTOR_TEMPLATE.format(
            image=image,
            port=port,
            model_path=model_path)
    else:
        if image is not None:
            log.info("Creating an InferenceService with predictor '%s'."
                     " Ignoring image...", predictor)
        if port is not None:
            log.info("Creating an InferenceService with predictor '%s'."
                     " Ignoring port...", predictor)
        predictor_spec = MINIO_PREDICTOR_TEMPLATE.format(predictor=predictor,
                                                         model_path=model_path)

    infs_spec = yaml.safe_load(RAW_TEMPLATE.format(name=name))
    predictor_spec = yaml.safe_load(predictor_spec)
    infs_spec["spec"]["default"]["predictor"] = predictor_spec

    if transformer:
        transformer_spec = yaml.safe_load(
            TRANSFORMER_CUSTOM_TEMPLATE.format(
                image=podutils.get_docker_base_image(),
                model_path=model_path
            ))
        infs_spec["spec"]["default"]["transformer"] = transformer_spec

    yaml_filename = "/tmp/%s.kfserving.yaml" % name
    yaml_contents = yaml.dump(infs_spec)
    log.info("Saving InferenceService definition at '%s'", yaml_filename)
    with open(yaml_filename, "w") as yaml_file:
        yaml_file.write(yaml_contents)

    if submit:
        _submit_inference_service(infs_spec, podutils.get_namespace())
    return KFServer(name=name, spec=yaml_contents)