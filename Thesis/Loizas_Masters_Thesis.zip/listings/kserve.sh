curl -s "https://raw.githubusercontent.com/kserve/kserve/release-0.7/hack/quick_install.sh" | bash

kubectl delete -f https://github.com/kserve/kserve/releases/download/v0.7.0/kserve.yaml

kubectl apply -f https://github.com/kubeflow/kfserving/releases/download/v0.6.0/kfserving.yaml

# set the following ENV vars in the app's Deployment
kubectl edit -n kfserving-system deployments.apps kfserving-models-web-app
# APP_PREFIX: /
# APP_DISABLE_AUTH: "True"
# APP_SECURE_COOKIES: "False"

# expose the app under localhost:5000
kubectl port-forward -n kfserving-system svc/kfserving-models-web-app 5000:80

# authorize network access to deployment
kubectl port-forward svc/istio-ingressgateway -n istio-system 8080:80