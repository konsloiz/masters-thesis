kubectl apply -k github.com/kubeflow/pipelines/manifests/kustomize/cluster-scoped-resources?ref=1.7.0

kubectl wait --for condition=established --timeout=60s crd/applications.app.k8s.io

kubectl apply -k github.com/kubeflow/pipelines/manifests/kustomize/env/dev?ref=1.7.0

kubectl port-forward -n kubeflow svc/ml-pipeline-ui 3000:80